library(tidyverse) # install.packages('tidyverse')
library(NonCompart)

my_data <- read_csv('oral-PK.csv')

my_data

# Hispanic Male

male_hispanic_data <- my_data %>% 
  filter(Gender == 'Male', Race == 'Hispanic')

male_hispanic_NCA <- tblNCA(as.data.frame(male_hispanic_data),
       key = 'ID', 'Time', 'Conc', dose = 5000, R2ADJ=0.1)

mean(male_hispanic_NCA$AUCLST)

# caucassian Female 


female_caucassian_data <- my_data %>% 
  filter(Gender == 'Female', Race == 'Caucasian') %>% 
  print()

female_caucassian_NCA <- tblNCA(as.data.frame(female_caucassian_data),
                            key = 'ID', 'Time', 'Conc', dose = 5000, R2ADJ=0.1)

mean(female_caucassian_NCA$AUCLST)

# Female, under 50

female_under50_data <- my_data %>% 
  filter(Gender == 'Female', Age < 50)

female_under50_NCA <- tblNCA(as.data.frame(female_under50_data),
       key = 'ID', 'Time', 'Conc', dose = 5000, R2ADJ=0.1)

mean(female_under50_NCA$AUCLST)
