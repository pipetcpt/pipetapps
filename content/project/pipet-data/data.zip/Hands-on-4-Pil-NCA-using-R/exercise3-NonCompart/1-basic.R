library(NonCompart)

Theoph_nca <- tblNCA(Theoph, "Subject", "Time", "conc", 
                     dose=320, concUnit="mg/L")
Theoph_nca

Indometh_nca <- tblNCA(Indometh, "Subject", "time", "conc", 
                       dose=25, adm="Bolus", dur=0.5, concUnit="mg/L", R2ADJ=0.5)
Indometh_nca

